/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package turnero;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Usuario
 */
@Entity
@Table(name = "Puesto")
public class Puesto {
    @Id
    private int nPuesto;
    @Column
    private Boolean estado;
    @Column
    private String servicio1;
    @Column
    private String servicio2;
    @Column
    private String servicio3;

    public int getnPuesto() {
        return nPuesto;
    }

    public void setnPuesto(int nPuesto) {
        this.nPuesto = nPuesto;
    }

    public Boolean getEstado() {
        return estado;
    }

    public void setEstado(Boolean estado) {
        this.estado = estado;
    }

    public String getServicio1() {
        return servicio1;
    }

    public void setServicio1(String servicio1) {
        this.servicio1 = servicio1;
    }

    public String getServicio2() {
        return servicio2;
    }

    public void setServicio2(String servicio2) {
        this.servicio2 = servicio2;
    }

    public String getServicio3() {
        return servicio3;
    }

    public void setServicio3(String servicio3) {
        this.servicio3 = servicio3;
    }

    public Puesto() {
    }

    public Puesto(int nPuesto, Boolean estado, String servicio1, String servicio2, String servicio3) {
        this.nPuesto = nPuesto;
        this.estado = estado;
        this.servicio1 = servicio1;
        this.servicio2 = servicio2;
        this.servicio3 = servicio3;
    }

    @Override
    public String toString() {
        return "Puesto{" + "nPuesto=" + nPuesto + ", estado=" + estado + ", servicio1=" + servicio1 + ", servicio2=" + servicio2 + ", servicio3=" + servicio3 + '}';
    }
    
}
