/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package turnero;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 *
 * @author Usuario
 */
@Entity
@Table(name = "Usuario")
public class Usuario extends Persona {
    @Column
    private int prioridad;
    @Column
    private String tipoIdentidad;

    public int getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(int prioridad) {
        this.prioridad = prioridad;
    }

    public String getTipoIdentidad() {
        return tipoIdentidad;
    }

    public void setTipoIdentidad(String tipoIdentidad) {
        this.tipoIdentidad = tipoIdentidad;
    }

    public Usuario() {
    }

    public Usuario(int prioridad, String tipoIdentidad, String identificacion, String nombre, String apellido, String telefono, String direccion) {
        super(identificacion, nombre, apellido, telefono, direccion);
        this.prioridad = prioridad;
        this.tipoIdentidad = tipoIdentidad;
    }

    @Override
    public String toString() {
        return "Usuario{" + "prioridad=" + prioridad + ", tipoIdentidad=" + tipoIdentidad + '}';
    }
    
}
