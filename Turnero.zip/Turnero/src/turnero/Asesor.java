/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package turnero;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 *
 * @author Usuario
 */
@Entity
@Table(name = "Asesor")
public class Asesor extends Persona{
    @Column
    private String tipoIdentidad;
    @Column
    private Boolean estado;

    public String getTipoIdentidad() {
        return tipoIdentidad;
    }

    public void setTipoIdentidad(String tipoIdentidad) {
        this.tipoIdentidad = tipoIdentidad;
    }

    public Boolean getEstado() {
        return estado;
    }

    public void setEstado(Boolean estado) {
        this.estado = estado;
    }

    public Asesor() {
    }

    public Asesor(String tipoIdentidad, Boolean estado, String identificacion, String nombre, String apellido, String telefono, String direccion) {
        super(identificacion, nombre, apellido, telefono, direccion);
        this.tipoIdentidad = tipoIdentidad;
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "Asesor{" + "tipoIdentidad=" + tipoIdentidad + ", estado=" + estado + '}';
    }
    
}
