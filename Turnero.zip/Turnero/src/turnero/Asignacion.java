/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package turnero;

import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Usuario
 */
@Entity
@Table(name = "Asignacion")
public class Asignacion {
    @Id
    private String nPuesto;
    @Id
    private String nTurno;
    @Column
    Calendar fecha = new GregorianCalendar();
    @Column
    Calendar horaEntrada = new GregorianCalendar();
    @Column
    Calendar horaSalida = new GregorianCalendar();

    public String getnPuesto() {
        return nPuesto;
    }

    public void setnPuesto(String nPuesto) {
        this.nPuesto = nPuesto;
    }

    public String getnTurno() {
        return nTurno;
    }

    public void setnTurno(String nTurno) {
        this.nTurno = nTurno;
    }

    public Calendar getFecha() {
        return fecha;
    }

    public void setFecha(Calendar fecha) {
        this.fecha = fecha;
    }

    public Calendar getHoraEntrada() {
        return horaEntrada;
    }

    public void setHoraEntrada(Calendar horaEntrada) {
        this.horaEntrada = horaEntrada;
    }

    public Calendar getHoraSalida() {
        return horaSalida;
    }

    public void setHoraSalida(Calendar horaSalida) {
        this.horaSalida = horaSalida;
    }

    public Asignacion() {
    }

    public Asignacion(String nPuesto, String nTurno) {
        this.nPuesto = nPuesto;
        this.nTurno = nTurno;
    }
    
    
    public void mostrarFecha(){
        int año = fecha.get(Calendar.YEAR);
        int mes = fecha.get(Calendar.MONTH);
        int dia = fecha.get(Calendar.DAY_OF_MONTH);
    }
    
    public void horaEntrada(){
        int hora = fecha.get(Calendar.HOUR_OF_DAY);
        int minuto = fecha.get(Calendar.MINUTE);
        int segundo = fecha.get(Calendar.SECOND);
    }

    public void horaSalida(){
        int hora = fecha.get(Calendar.HOUR_OF_DAY);
        int minuto = fecha.get(Calendar.MINUTE);
        int segundo = fecha.get(Calendar.SECOND);
    }
    
}
