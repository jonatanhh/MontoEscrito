/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package turnero;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Usuario
 */
@Entity
@Table(name = "Turno")
public class Turno {
    @Id
    private String idTurno;
    @Column
    private int prioridad;
    @Column
    private String tipoServicio;

    public String getIdTurno() {
        return idTurno;
    }

    public void setIdTurno(String idTurno) {
        this.idTurno = idTurno;
    }

    public int getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(int prioridad) {
        this.prioridad = prioridad;
    }

    public String getTipoServicio() {
        return tipoServicio;
    }

    public void setTipoServicio(String tipoServicio) {
        this.tipoServicio = tipoServicio;
    }

    public Turno() {
    }

    public Turno(String idTurno, int prioridad, String tipoServicio) {
        this.idTurno = idTurno;
        this.prioridad = prioridad;
        this.tipoServicio = tipoServicio;
    }

    @Override
    public String toString() {
        return "Turno{" + "idTurno=" + idTurno + ", prioridad=" + prioridad + ", tipoServicio=" + tipoServicio + '}';
    }
    
}
